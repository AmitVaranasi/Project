<?php session_start() ; ?> 
<head>
    <title>Pricing</title>
    <link href='https://fonts.googleapis.com/css?family=Muli' rel='stylesheet'>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body{

        background-color:rgb(206,233,242) ;

        font-family: 'Muli',sans-serif;
       }
        img{
            padding-top:10px;
            height:110px;
        }
    </style>
</head>
<body>
    <?php include 'header.php' ?>
    <script>
     document.getElementById("div1").style.backgroundColor = 'rgb(21,111,184)';
     document.getElementById("div2").style.backgroundColor = 'white';
     document.getElementById("div3").style.backgroundColor = 'white';
     document.getElementById("div4").style.backgroundColor = 'white';

     function content(id){

         var button_name = id;

         console.log("Im button "+ button_name);

  if(button_name==="div1")

 {

     document.getElementById("steam").style.display='block';
     document.getElementById("div1").style.backgroundColor = 'rgb(21,111,184)';

    //  document.getElementById("child1").style.backgroundColor = "#"+(21).toString(16)+(111).toString(16)+(184).toString(16);

     document.getElementById("div2").style.backgroundColor = 'white';

     document.getElementById("div3").style.backgroundColor = 'white';

     document.getElementById("div4").style.backgroundColor = 'white';

     document.getElementById("washandpress").style.display='none';

     document.getElementById("washandfold").style.display='none';

     document.getElementById("drycleaning").style.display='none';

 }

 else  if( button_name==="div2")

 {

    document.getElementById("steam").style.display='none';
    document.getElementById("div2").style.backgroundColor = 'rgb(21,111,184)';
    document.getElementById("div1").style.backgroundColor = 'white';

     document.getElementById("div3").style.backgroundColor = 'white';

     document.getElementById("div4").style.backgroundColor = 'white';
     document.getElementById("washandpress").style.display='block';

     document.getElementById("washandfold").style.display='none';

     document.getElementById("drycleaning").style.display='none';



 }

 else  if( button_name==="div3")

 {

    document.getElementById("steam").style.display='none';

     document.getElementById("washandpress").style.display='none';

     document.getElementById("washandfold").style.display='block';

     document.getElementById("drycleaning").style.display='none';
     document.getElementById("div3").style.backgroundColor = 'rgb(21,111,184)';
     document.getElementById("div2").style.backgroundColor = 'white';

     document.getElementById("div1").style.backgroundColor = 'white';

     document.getElementById("div4").style.backgroundColor = 'white';



 }

 else  if( button_name==="div4")

 {

    document.getElementById("steam").style.display='none';

     document.getElementById("washandpress").style.display='none';

     document.getElementById("washandfold").style.display='none';

     document.getElementById("drycleaning").style.display='block';
     document.getElementById("div4").style.backgroundColor = 'rgb(21,111,184)';
     document.getElementById("div2").style.backgroundColor = 'white';

     document.getElementById("div3").style.backgroundColor = 'white';

     document.getElementById("div1").style.backgroundColor = 'white';


 }

 else{

    document.getElementById("steam").style.display='block';

     document.getElementById("washandpress").style.display='none';

     document.getElementById("washandfold").style.display='none';

     document.getElementById("drycleaning").style.display='none';

     





 }

}



</script>


    <div class="container">

     <div class="mb-auto row" >

    

        <div class="d-flex flex-column flex-nowrap justify-content-between col-md-3" style="background-color:rgb(206,233,242) ;">

                <li class="btn active" id="div1" onclick="content(this.id)" style="height:20vh;">
                    
                     <img class="abc" src="img/steampress1.png" style="float:left" alt="steampress">
                     <span class="ab">Steam Press<span><br>
                     <span class="ab">(48 hrs)</span>



                    

                </li>

                <li class="btn " id="div2" onclick="content(this.id)" style="height:20vh;">

                    
                        <img class="abc" src="img/washandpress1.png" style="float:left" alt="wash and press">

                                

                        <span class="ab">Wash & Press</span><br>

                        <span  class="ab">(2-3 days)</span>


                        
                        
                    
                </li>

                <li class="btn " id="div3" onclick="content(this.id)" style="height:20vh;">

                   

                        <img class="abc" src="img/washandfold1.png" style="float:left" alt="Wash and Fold">

                                

                        <span  class="ab">Wash & Fold</span><br>

                        <span  class="ab">(2-3 days)</span>



                

                </li>

                <li class="btn " id="div4" onclick="content(this.id)" style="height:20vh;">

            
                        
                        <img class="abc" src="img/dry1.png" style="float:left" alt="Dry cleaning">

                                

                        <span  class="ab">Dry cleaning</span><br>

                        <span  class="ab">(3-4 days)</span>

                  

                </li>

        

    </div>

        <div class="d-flex flex-column flex-nowrap justify-content-start col-md-9 "id="row1">

            <div id="steam">

                
                    <?php 
                    
                    $conn = mysqli_connect('localhost','root','Himavarsha','login_swe') or die('Unable To connect');
                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    } 
                    
                    $sql = "SELECT id_p,name,price  FROM price where item_id= 'Steam Press' ";
                    $result = $conn->query($sql);
                    
                    if ($result->num_rows > 0) {
                        //echo "<div id='a'><table>";
                        // output data of each row
                        while($row = $result->fetch_assoc()) {
                            echo "<div id='a'><table>";
                            echo "<tr>

                            <td>

                                <small>ITEM TYPE</small>

                            </td>

                            <td><small>PRICE</small></td>

                        </tr>";
                            echo "<tr><td class = 'col-md-6'>".$row["name"]."</td><td class = 'col-md-3'> <b>&#8377</b>".$row["price"]."/piece</td></tr>";
                            echo "</table> </div>";
                        }
                        
                    } else {
                        echo "0 results";
                    }
                    $conn->close();
                    ?>
                    

                    

        



      </div>

      

    <div id="washandpress">

    <?php 
                    
                    $conn = mysqli_connect('localhost','root','Himavarsha','login_swe') or die('Unable To connect');
                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    } 
                    
                    $sql = "SELECT id_p,name,price  FROM price where item_id= 'wash&press' ";
                    $result = $conn->query($sql);
                    
                    if ($result->num_rows > 0) {
                        //echo "<div id='a'><table>";
                        // output data of each row
                        while($row = $result->fetch_assoc()) {
                            echo "<div id='a'><table>";
                            echo "<tr>

                            <td>

                                <small>ITEM TYPE</small>

                            </td>

                            <td><small>PRICE</small></td>

                        </tr>";
                            echo "<tr><td class = 'col-md-6'>".$row["name"]."</td><td class = 'col-md-3'> <b>&#8377</b>".$row["price"]."</td></tr>";
                            echo "</table> </div>";
                        }
                        
                    } else {
                        echo "0 results";
                    }
                    $conn->close();
                    ?>
    



  </div>

  <div id="washandfold" >
  <?php 
                    
                    $conn = mysqli_connect('localhost','root','Himavarsha','login_swe') or die('Unable To connect');
                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    } 
                    
                    $sql = "SELECT id_p,name,price  FROM price where item_id= 'wash&fold' ";
                    $result = $conn->query($sql);
                    
                    if ($result->num_rows > 0) {
                        //echo "<div id='a'><table>";
                        // output data of each row
                        while($row = $result->fetch_assoc()) {
                            echo "<div id='a'><table>";
                            echo "<tr>

                            <td>

                                <small>ITEM TYPE</small>

                            </td>

                            <td><small>PRICE</small></td>

                        </tr>";
                            echo "<tr><td class = 'col-md-6'>".$row["name"]."</td><td class = 'col-md-3'> <b>&#8377</b>".$row["price"]."</td></tr>";
                            echo "</table> </div>";
                        }
                        
                    } else {
                        echo "0 results";
                    }
                    $conn->close();
                    ?>

    


</div>

<div id="drycleaning">

<?php 
                    
                    $conn = mysqli_connect('localhost','root','Himavarsha','login_swe') or die('Unable To connect');
                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    } 
                    
                    $sql = "SELECT id_p,name,price  FROM price where item_id= 'Dry cleaning' ";
                    $result = $conn->query($sql);
                    
                    if ($result->num_rows > 0) {
                        //echo "<div id='a'><table>";
                        // output data of each row
                        while($row = $result->fetch_assoc()) {
                            echo "<div id='a'><table>";
                            echo "<tr>

                            <td>

                                <small>ITEM TYPE</small>

                            </td>

                            <td><small>PRICE</small></td>

                        </tr>";
                            echo "<tr><td class = 'col-md-6'>".$row["name"]."</td><td class = 'col-md-3'> <b>&#8377</b>".$row["price"]."</td></tr>";
                            echo "</table> </div>";
                        }
                        
                    } else {
                        echo "0 results";
                    }
                    $conn->close();
                    ?>





</div>

  

    </div>

     
    

        <div class="row" style="text-align:center ; height:10vh;background-color:rgb(206,233,242);width:100%" >

  

          <div style="width:100%;height:100%;padding-bottom: 20px;">

              <?php   if(isset( $_SESSION['user'] )){ ?>
                  <a href="bookNow.php">
                      <input type="button" value="Book Now" style="text-align:center;color:white;font-weight:bolder;font-size:25px;background-color:rgb(21, 111, 184);width: 25% ; height:9vh; border :2px solid black; border-radius: 5px;">
                  </a>
             <?php }else{ ?>
                  <input type="button" onclick=func() value="Book Now" style="text-align:center;color:white;font-weight:bolder;font-size:25px;background-color:rgb(21, 111, 184);width: 25% ; height:9vh; border :2px solid black; border-radius: 5px;">
                 <script> function func(){alert("Please login");} </script>
              <?php  } ?>

            </div>
        </div>

</div>

</div>

</body>