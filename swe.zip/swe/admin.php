<?php session_start() ; 
    include 'header1.php';
?>
<head>
  <style>
    #a1{
      padding:10px;
    }
  </style>
</head>
<?php
    $conn = mysqli_connect('localhost','root','Himavarsha','login_swe') or die('Unable To connect');
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 
    
    $sql = "SELECT *  FROM confirm ";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        //echo "<div id='a'><table>";
        // output data of each row
        echo "<div id='a1'><table class='table'><thead class='thead-light'><tr><th scope='col'><b>Order Id</b></th>
        <th scope='col'><b>User Name</b></th>
        <th scope='col'><b>Service</b></th>
        <th scope='col'><b>Date</b></th>
        <th scope='col'><b>Order Type</b></th>
        <th scope='col'><b>Order Status</b></th>
        <th scope='col'><b></b></th></tr></thead>";
        while($row = $result->fetch_assoc()) {
            echo "<form method = 'post' ><div id='a'>";
            echo "<tr>
            <td ><input type = 'text' name = 'order_id' value = ".$row["order_id"]." readonly></td>
            <td ><input type = 'text' name = 'order_id1' value = ".$row["user_name"]." readonly></td>
            <td ><input type = 'text' name = 'order_id2' value = ".$row["service"]."</td>
            <td ><input type = 'text' name = 'order_id3' value = ".$row["time"]." readonly></td>
            <td ><input type = 'text' name = 'order_id4' value = ".$row["oder"]." readonly></td>
            <td ><input id = type= 'text' name = 'status' value = ".$row["status"]."></td>
            <td ><input type ='submit' name = 'submit' class='btn btn-cyan' value = 'process'></td>
            </tr>";
            echo " </div></form>";
        }
        echo "</table>";
        
    } else {
        echo "0 results";
    }
    $conn->close();

?>
<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST'){

  
        if(isset($_POST['submit'])){?>
           
           <?php 
             $con = mysqli_connect('localhost','root','Himavarsha','login_swe') or die('Unable To connect');
             $o= mysqli_real_escape_string($con,$_POST['order_id']);
             $stat = mysqli_real_escape_string($con,$_POST['status']);
             
             if(empty($stat)){
                 ?>
                 <script>alert("please enter all the values")</script>
             <?php }
             else{
                
                
             $t = "update confirm SET status = ? where order_id = $o";
             $s = mysqli_prepare($con, $t);
             mysqli_stmt_bind_param($s, 's', $stat);
             if(mysqli_stmt_execute($s)){//echo "success";?>
               <script>
               location('http://localhost/swe/admin.php')
               </script>
     
             <?php  
             }
             else{
               echo "failure";
             }
            // header('location:admin.php'); 
           }       
         }
       }
       
?>

