<?php session_start() ; ?> 
<?php include 'header.php' ; ?>
<table style="width: 720px; height: 1069px; margin-right: auto; margin-left: auto;">

    <tbody>

    <tr>

    <td style="width: 349.25px;"><img style="margin-right: 85px; margin-right: 20px;" src="1.png"  /></td>

    <td style="width: 353.75px;">

    <h3><span style="color: #800080;">REFER YOUR FRIEND AND EARN Rs.75</span></h3>

    <div>Get a chance to earn 75 LK credits by referring your friend to LaundroKart. <br> <br> Friend gets 75 LK Credits on registration. Friend orders first time, you get 75 LK Credits. <br><br>Spread the word by sharing your unique referral code to your friends. <br><br> You&rsquo;ll get paid for every new friend that signs up to Laundrokart and orders. Go ahead and share your referral code to as many people as you can and earn big! <br><br></div>

    <ol style="font: inherit; list-style: decimal; margin: 0px 0px 10px; padding: 0px 0px 0px 20px; border: 0px; color: #333333; text-transform: none; text-indent: 0px; letter-spacing: normal; text-decoration: none; word-spacing: 0px; white-space: normal; box-sizing: border-box; orphans: 2; font-size-adjust: none; font-stretch: inherit; -webkit-text-stroke-width: 0px;">

    <li style="box-sizing: border-box; font-size: 12px;">Offer valid till 31/05/2019</li>

    <li style="box-sizing: border-box; font-size: 12px;">Offer valid on min transaction of ₹360.</li>

    <li style="box-sizing: border-box; font-size: 12px;">Standard <a style="background-color: transparent; border-image-outset: 0; border-image-repeat: stretch; border-image-slice: 100%; border-image-source: none; border-image-width: 1; box-sizing: border-box; color: #337ab7; font-family: inherit; font-size: inherit; font-size-adjust: none; font-stretch: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; line-height: inherit; text-decoration: none; padding: 0px; margin: 0px; border: 0px none currentColor;" href="https://www.laundrokart.com/termsandconditions" target="_blank" rel="noopener"> Terms and Conditions</a> apply.</li>

    </ol>

    </td>

    </tr>

    <tr>

    <td style="width: 349.25px;">

    <p style="border-image-outset: 0; border-image-repeat: stretch; border-image-slice: 100%; border-image-source: none; border-image-width: 1; box-sizing: border-box; color: inherit; font-family: &amp;quot; open sans&amp;quot;,sans-serif; font-size: 18px; font-size-adjust: none; font-stretch: inherit; font-style: inherit; font-variant: inherit; font-weight: 500; letter-spacing: normal; line-height: 30px; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: uppercase; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px; border-width: 0px 0px 1px 0px; border-color: currentColor currentColor #f1f1f1 currentColor; border-style: none none solid none; padding: 0px; margin: 20px 0px 8px -10px;"><strong>Silver Lining&nbsp;for your Clothes</strong></p>

    <p style="border-image-outset: 0; border-image-repeat: stretch; border-image-slice: 100%; border-image-source: none; border-image-width: 1; box-sizing: border-box; color: #333333; font-family: inherit; font-size: inherit; font-size-adjust: none; font-stretch: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; letter-spacing: normal; line-height: inherit; orphans: 2; text-align: ; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px; padding: 0px; margin: 0px 10px 10px -9pt; border: 0px none currentColor;">

    Get a month's laundry done at Rs.1000. Suitable for a Person</p>

    <p style="border-image-outset: 0; border-image-repeat: stretch; border-image-slice: 100%; border-image-source: none; border-image-width: 1; box-sizing: border-box; color: #333333; font-family: inherit; font-size: inherit; font-size-adjust: none; font-stretch: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; letter-spacing: normal; line-height: inherit; orphans: 2; text-align: justify; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px; padding: 0px; margin: 0px 0px 10px -9pt; border: 0px none currentColor;">Staying away from home is sad, with all chores to be taken care, but LaundroKart is at your rescue for laundry. Buy our Silver Package at Rs.1000/-, avail services for Rs.1050/ and get your laundry done. We believe in giving you time to pamper yourself.</p>

    </td>

    <td style="width: 353.75px;"><img style="margin-right: 10px; margin-left:20px;"  src="2.png" /></td>

    </tr>

    <tr>

    <td style="width: 349.25px;">

    <p style="border-image-outset: 0; border-image-repeat: stretch; border-image-slice: 100%; border-image-source: none; border-image-width: 1; box-sizing: border-box; color: inherit; font-family: &amp;quot; open sans&amp;quot;,sans-serif; font-size: 18px; font-size-adjust: none; font-stretch: inherit; font-style: inherit; font-variant: inherit; font-weight: 500; letter-spacing: normal; line-height: 30px; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: uppercase; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px; border-width: 0px 0px 1px 0px; border-color: currentColor currentColor #f1f1f1 currentColor; border-style: none none solid none; padding: 0px; margin: 20px 0px 8px -10px;"><img src="3.png" alt=""  style="margin-right: 10px;"/></p>

    </td>

    <td style="width: 353.75px;">

    <p style="border-image-outset: 0; border-image-repeat: stretch; border-image-slice: 100%; border-image-source: none; border-image-width: 1; box-sizing: border-box; color: inherit; font-family: &amp;quot; open sans&amp;quot;,sans-serif; font-size: 18px; font-size-adjust: none; font-stretch: inherit; font-style: inherit; font-variant: inherit; font-weight: 500; letter-spacing: normal; line-height: 30px; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: uppercase; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px; border-width: 0px 0px 1px 0px; border-color: currentColor currentColor #f1f1f1 currentColor; border-style: none none solid none; padding: 0px; margin: 20px 0px 8px -10px;"><strong>Golden touch for your clothes</strong></p>

    <p style="border-image-outset: 0; border-image-repeat: stretch; border-image-slice: 100%; border-image-source: none; border-image-width: 1; box-sizing: border-box; color: #333333; font-family: inherit; font-size: inherit; font-size-adjust: none; font-stretch: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; letter-spacing: normal; line-height: inherit; orphans: 2; text-align: justify; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px; padding: 0px; margin: 0px 0px 10px -9pt; border: 0px none currentColor;">Get a month&rsquo;s laundry done at Rs.2000. Suitable for 2</p>

    <p style="border-image-outset: 0; border-image-repeat: stretch; border-image-slice: 100%; border-image-source: none; border-image-width: 1; box-sizing: border-box; color: #333333; font-family: inherit; font-size: inherit; font-size-adjust: none; font-stretch: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; letter-spacing: normal; line-height: inherit; orphans: 2; text-align: justify; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px; padding: 0px; margin: 0px 0px 10px -9pt; border: 0px none currentColor;">Newly Married or Office goers, need time to spend with your family, don&rsquo;t worry we are here. We understand the importance of family time and would love to give your memories to cherish. Buy our Gold Package at Rs.2000, avail services for Rs.2150/- and your laundry is covered for a family of 2.</p>

    </td>

    </tr>

    <tr>

    <td style="width: 349.25px;">

    <p style="border-image-outset: 0; border-image-repeat: stretch; border-image-slice: 100%; border-image-source: none; border-image-width: 1; box-sizing: border-box; color: inherit; font-family: &amp;quot; open sans&amp;quot;,sans-serif; font-size: 18px; font-size-adjust: none; font-stretch: inherit; font-style: inherit; font-variant: inherit; font-weight: 500; letter-spacing: normal; line-height: 30px; orphans: 2; text-align: left; text-decoration: none; text-indent: 0px; text-transform: uppercase; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px; border-width: 0px 0px 1px 0px; border-color: currentColor currentColor #f1f1f1 currentColor; border-style: none none solid none; padding: 0px; margin: 20px 0px 8px -10px;"><strong>Platinum for ever</strong></p>

    <p style="border-image-outset: 0; border-image-repeat: stretch; border-image-slice: 100%; border-image-source: none; border-image-width: 1; box-sizing: border-box; color: #333333; font-family: inherit; font-size: inherit; font-size-adjust: none; font-stretch: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; letter-spacing: normal; line-height: inherit; orphans: 2; text-align: justify; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px; padding: 0px; margin: 0px 0px 10px -9pt; border: 0px none currentColor;">Get a month&rsquo;s laundry done at Rs.3000. Suitable for a family</p>

    <p style="border-image-outset: 0; border-image-repeat: stretch; border-image-slice: 100%; border-image-source: none; border-image-width: 1; box-sizing: border-box; color: #333333; font-family: inherit; font-size: inherit; font-size-adjust: none; font-stretch: inherit; font-style: inherit; font-variant: inherit; font-weight: inherit; letter-spacing: normal; line-height: inherit; orphans: 2; text-align: justify; text-decoration: none; text-indent: 0px; text-transform: none; -webkit-text-stroke-width: 0px; white-space: normal; word-spacing: 0px; padding: 0px; margin: 0px 0px 10px -9pt; border: 0px none currentColor;">Spending quality time with family is always a priority but with daily chores, it becomes difficult. We at your rescue would love to get your laundry done. So avail our services with our Platinum package at Rs.3000.&nbsp;Buy our Platinum Package at Rs.3000, avail services for Rs.3300/- This will help you get your laundry done for the entire family.</p>

    </td>

    <td style="width: 353.75px;"><img style="margin-right: 95px; margin-left: 20px;" src="4.png" alt=""  /></td>

    </tr>

    </tbody>

    </table>

    <p>&nbsp;</p>   